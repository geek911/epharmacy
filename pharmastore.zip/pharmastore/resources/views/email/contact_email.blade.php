<table>
    <tr>
        <td><strong>Name:</strong></td>
        <td>{{$data['name']}}</td>
    </tr>
    <tr>
        <td><strong>Phone:</strong></td>
        <td>{{$data['phone']}}</td>
    </tr>
    <tr>
        <td><strong>Email:</strong></td>
        <td>{{$data['email']}}</td>
    </tr>
    <tr>
        <td colspan="2"><strong>Message:</strong></td>
    </tr>
    <tr>
        <td colspan="2">{{$data['message']}}</td>
    </tr>
</table>