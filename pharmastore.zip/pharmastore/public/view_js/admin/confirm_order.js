  "use strict";
  window.onload = function() {
      sessionStorage.removeItem("shoppingCart")
  }