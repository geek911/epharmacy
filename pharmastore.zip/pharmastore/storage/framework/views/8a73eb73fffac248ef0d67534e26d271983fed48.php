<?php $__env->startSection('content'); ?>
<section class="breadcrumb-section">
    <h2 class="sr-only">Site Breadcrumb</h2>
    <div class="container">
        <div class="breadcrumb-contents">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                    <li class="breadcrumb-item active">Search Result</li>
                </ol>
            </nav>
        </div>
    </div>
</section>
<main class="inner-page-sec-padding-bottom">
    <div class="container">
        
        
        <div class="shop-product-wrap grid with-pagination row space-db--30 shop-border">
            
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-sm-6">
                <div class="product-card">
                    <div class="product-grid-content">
                        <div class="product-header">
                            <a href="" class="author">
                            <?php echo e($eachProduct->generic->name); ?>

                            </a>
                            <h3><a href="<?php echo e(route('p_details', $eachProduct->id)); ?>"><?php echo e($eachProduct->name); ?></a></h3>
                        </div>
                        <div class="product-card--body">
                            <div class="card-image">
                                <img src="<?php echo e(asset($eachProduct->image)); ?>" alt="">
                                <div class="hover-contents">
                                    <a href="<?php echo e(route('p_details', $eachProduct->id)); ?>" class="hover-image">
                                        <img src="<?php echo e(asset($eachProduct->image)); ?>" alt="">
                                    </a>
                                    <div class="hover-btns">
                                        <a href="javascript:void();" class="single-btn add-to-cart" data-id="<?php echo e($eachProduct->id); ?>" index-id="<?php echo e($loop->index); ?>">
                                            <i class="fas fa-shopping-basket"></i>
                                        </a>
                                        <a href="<?php echo e(route('p_details', $eachProduct->id)); ?>" class="single-btn">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="price-block">
                                <span class="price">£<?php echo e($eachProduct->sellingPrice); ?></span>
                                <del class="price-old">£<?php echo e($eachProduct->sellingPrice); ?></del>
                                
                            </div>
                        </div>
                    </div>
                    <div class="product-list-content">
                        <div class="card-image">
                            <img src="image/products/product-3.jpg" alt="">
                        </div>
                        <div class="product-card--body">
                            <div class="product-header">
                                <a href="" class="author">
                                    Gpple
                                </a>
                                <h3><a href="product-details.html" tabindex="0">Qpple cPad with Retina Display
                                        MD510LL/A</a></h3>
                            </div>
                            <article>
                                <h2 class="sr-only">Card List Article</h2>
                                <p>More room to move. With 80GB or 160GB of storage and up to 40 hours of
                                    battery life, the new iPod classic lets you enjoy
                                    up to 40,000 songs or..</p>
                            </article>
                            <div class="price-block">
                                <span class="price">£51.20</span>
                                <del class="price-old">£51.20</del>
                                <span class="price-discount">20%</span>
                            </div>
                            <div class="rating-block">
                                <span class="fas fa-star star_on"></span>
                                <span class="fas fa-star star_on"></span>
                                <span class="fas fa-star star_on"></span>
                                <span class="fas fa-star star_on"></span>
                                <span class="fas fa-star "></span>
                            </div>
                            <div class="btn-block">
                                <a href="" class="btn btn-outlined">Add To Cart</a>
                                <a href="" class="card-link"><i class="fas fa-heart"></i> Add To Wishlist</a>
                                <a href="" class="card-link"><i class="fas fa-random"></i> Add To Cart</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        <!-- Pagination Block -->
        
        <!-- Modal -->
       
    </div>
</main>
<script>
    "use strict";
    var productArray=<?php echo json_encode($products, 15, 512) ?>;            
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pharmastore\resources\views/frontend/search_product.blade.php ENDPATH**/ ?>