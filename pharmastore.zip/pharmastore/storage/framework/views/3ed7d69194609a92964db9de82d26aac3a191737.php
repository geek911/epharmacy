<?php $__env->startSection('title'); ?>
  Generic Name Add
<?php $__env->stopSection(); ?> 


<?php $__env->startSection('sideMenuTitle'); ?>
  Generic Name Add
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageTitle'); ?>
<a href="<?php echo e(url('genericnames/list')); ?>"><i class="fa fa-dashboard"></i>Generic List</a>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('bodyContent'); ?>

 <section class="content">
  <?php if(Session::has('message')): ?>
  <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h4><i class="icon fa fa-check"></i>
                <?php echo e(Session::get('message')); ?></h4>
     </div>
     <?php endif; ?>

      <?php if(Session::has('error')): ?>
      <div class="alert alert-danger alert-warning alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <h4><i class="icon fa fa-check"></i>
                    <?php echo e(Session::get('error')); ?></h4>
         </div>
     <?php endif; ?>
    
      <?php if($errors->any()): ?>
        <div class="alert alert-danger alert-warning alert-dismissible">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
      <div class="row">
        <!-- left column -->
        <div class="col-lg-12 centerDiv">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title"></h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <?php if(!isset($editData)): ?>
            <?php echo Form::open(['url' => 'genericnames/add', 'method' => 'post', 'name' => 'form', 'enctype' => 'multipart/form-data',  'role' => 'form']); ?>

            <?php endif; ?>
            <?php if(isset($editData)): ?>
            <?php echo Form::open(['url' => 'genericnames/update', 'method' => 'post','name' => 'form', 'enctype' => 'multipart/form-data', 'role' => 'form']); ?>

            <input type="hidden" class="form-control" name="id" value="<?php echo e($editData->id); ?>">
            <?php endif; ?>
              <div class="box-body">
                <div class="form-group">
                  <label for="exampleInputEmail1">Generic Name</label>
                  <input type="text" class="form-control" name="name" placeholder="Name" value="<?php echo e(isset($editData) ? $editData->name:old('name')); ?>" required>
                </div>
                <div class="form-group">
                  <label>Select Publis Status</label>
                  <select class="form-control" name="status" required>
                        <?php $__currentLoopData = $publish; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($pub->id); ?>" <?php echo e((isset($editData) ? ($editData->status == $pub->id ? 'selected="selected"' : '') : ($loop->first ? 'selected="selected"' : '' ) )); ?> ><?php echo e($pub->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                  </select>
                </div>
               
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>
      <?php echo Form::close(); ?>

           
           
          </div>
          <!-- /.box -->

         
    </div> 
  </div>
</section>             
  
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pharmastore\resources\views/admin/GenericNames/genericNameAdd.blade.php ENDPATH**/ ?>